#ifndef __SYSINIT_H
#define __SYSINIT_H
/* DriverLib Includes */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
/****************************************************/
//MSP432P401R
//ʱ������
//Bilibili��m-RNA
//E-mail:m-RNA@qq.com
//��������:2021/8/11
/****************************************************/

void SysInit(void);

#endif
